# wordpress-woocommerce
Плагин для автоматического расчета стоимости доставки с модулем woocommerce
